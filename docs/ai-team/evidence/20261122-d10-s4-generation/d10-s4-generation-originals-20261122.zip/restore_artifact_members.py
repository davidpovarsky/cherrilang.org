"""Reconstitute retained ZIP members for read-only intake; no network or CI execution."""
import hashlib
import json
from pathlib import Path
import stat
import zipfile

root = Path(__file__).resolve().parent
api = json.loads(json.loads((root / "artifacts.github-response.original.json").read_text())["structuredContent"]["content"])
assert {entry["id"] for entry in api["artifacts"]} == {14733852372, 14733458610, 14733304387}
for entry in api["artifacts"]:
    archive = root / (str(entry["id"]) + ".original.zip")
    raw = archive.read_bytes()
    assert len(raw) == entry["size_in_bytes"]
    assert "sha256:" + hashlib.sha256(raw).hexdigest() == entry["digest"]
    manifest = json.loads((root / (str(entry["id"]) + ".member-manifest.json")).read_text())
    expected = {item["path"]: item for item in manifest}
    assert len(expected) == len(manifest)
    destination = root / (str(entry["id"]) + ".members")
    existed = destination.exists()
    if not existed:
        destination.mkdir()
    assert destination.is_dir() and not destination.is_symlink()
    with zipfile.ZipFile(archive) as z:
        assert len(z.namelist()) == len(set(z.namelist())) and set(z.namelist()) == set(expected)
        for item in z.infolist():
            path = Path(item.filename)
            assert not path.is_absolute() and ".." not in path.parts and not stat.S_ISLNK(item.external_attr >> 16)
            data = z.read(item)
            assert len(data) == expected[item.filename]["bytes"]
            assert hashlib.sha256(data).hexdigest() == expected[item.filename]["sha256"]
            target = destination / path
            if existed:
                assert target.is_file() and not target.is_symlink() and target.read_bytes() == data
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("xb") as output:
                    output.write(data)
    assert {p.relative_to(destination).as_posix() for p in destination.rglob("*") if p.is_file()} == set(expected)
print("Verified/reconstituted all 200 original artifact members without CI execution.")
