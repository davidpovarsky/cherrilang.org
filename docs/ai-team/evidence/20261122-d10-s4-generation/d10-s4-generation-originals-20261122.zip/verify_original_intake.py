"""Read-only reconciliation of the one original D10 GitHub run; invokes no compiler."""
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
DOCS = "151111f7f67ed4980b243065fbd606a5902f734b"
COMPILER = "b791ce0616d1821cebfc57909a6bc50a195ca68c"
RUN = 44971464321
BINARY = "65042016b5c973d71a7409b844482d73d26e5dd6327f945f851915e5facdebc6"
PACKAGE = "github.com/electrikmilk/cherri/tools/language-docs"
PARENTS = ("TestGeneratedReferenceIncludesSeparateMacroContracts", "TestP15D01PrimaryParameterContract",
           "TestP15D01AllGeneratedSignaturesAndCategories", "TestP15D01CheckGateProducesAndRejectsFaults")
MUTATIONS = ("optional_primary", "typed_default", "callable_identity", "wire_key", "return_type",
             "macro_identity", "missing_category", "extra_section")
TESTS = set(PARENTS) | {PARENTS[-1] + "/" + name for name in MUTATIONS}
FRONT = b"---\ntitle: Actions Reference\nparent: Language v2.0\nlayout: default\nnav_order: 2\npermalink: /fork-language/actions\n---\n\n"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            assert key not in result, key
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def read(path):
    return strict(path.read_bytes())


def api(label):
    return strict(read(ROOT / (label + ".github-response.original.json"))["structuredContent"]["content"])


def utc(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    assert result.utcoffset().total_seconds() == 0
    return result


def bound(raw, witness):
    assert len(raw) == witness["bytes"] and sha(raw) == witness["sha256"]


run, jobs, artifacts = api("run"), api("jobs"), api("artifacts")
assert run["id"] == RUN and run["head_sha"] == DOCS and run["run_attempt"] == 1
assert (run["status"], run["conclusion"]) == ("completed", "success")
assert jobs["total_count"] == len(jobs["jobs"]) == 2
assert {job["id"] for job in jobs["jobs"]} == {137051965496, 137051965733}
assert all(job["head_sha"] == DOCS and job["run_attempt"] == 1 and job["conclusion"] == "success" for job in jobs["jobs"])
job = next(job for job in jobs["jobs"] if job["id"] == 137051965733)
assert artifacts["total_count"] == len(artifacts["artifacts"]) == 3
artifact_rows = []
for entry in artifacts["artifacts"]:
    raw = (ROOT / (str(entry["id"]) + ".original.zip")).read_bytes()
    assert entry["workflow_run"]["head_sha"] == DOCS and entry["workflow_run"]["id"] == RUN
    assert entry["size_in_bytes"] == len(raw) and entry["digest"] == "sha256:" + sha(raw)
    members = read(ROOT / (str(entry["id"]) + ".member-manifest.json"))
    with zipfile.ZipFile(ROOT / (str(entry["id"]) + ".original.zip")) as z:
        assert len(z.namelist()) == len(set(z.namelist())) == len(members)
        for member in members:
            data = z.read(member["path"])
            bound(data, member)
            assert data == (ROOT / (str(entry["id"]) + ".members") / member["path"]).read_bytes()
    artifact_rows.append({"id": entry["id"], "name": entry["name"], "bytes": len(raw), "sha256": sha(raw), "members": len(members)})

source_bytes, source_blobs = {}, {}
for file in sorted(ROOT.glob("source-*.github-response.original.json")):
    value = read(file)["structuredContent"]
    if "sha" not in value:  # Commit API is a separately retained carrier.
        continue
    data = value["content"].encode("utf-8")
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == value["sha"]
    label = file.name[len("source-"):].split(".github-response")[0]
    source_bytes[label] = data
    source_blobs[label] = {"git_blob": blob, "bytes": len(data), "sha256": sha(data), "url": value["display_url"]}
    (ROOT / ("source-" + label + ".txt")).write_bytes(data)

g = ROOT / "14733458610.members"
report = read(g / "generation-report.json")
assert report["schema"] == "cherri.docs-generated-reference-ci/v1"
assert report["docs_source"] == DOCS and report["compiler_source"] == COMPILER
assert report["passed"] is True and report["sources_unchanged"] is True
assert report["formal_acceptance_granted"] is False and report["apple_runtime_proved"] is False
assert report["before"] == report["after"]
begin, end = utc(report["started_utc"]), utc(report["finished_utc"])
assert utc(job["started_at"]) <= begin < end <= utc(job["completed_at"])
suffixes = ["cache-1", "cache-2", "cache-3", "cache-4", "compiler-head", "compiler-root", "compiler-status", "compiler-stage", "compiler-flags", "docs-head", "docs-root", "docs-status", "docs-stage", "docs-flags", "docs-origin"]
labels = ["before-" + name for name in suffixes] + ["generate", "check", "go-controls"] + ["after-" + name for name in suffixes]
assert [p["label"] for p in report["processes"]] == labels
processes = {p["label"]: p for p in report["processes"]}
previous = begin
for label in labels:
    row = processes[label]
    assert read(g / (label + ".process.json")) == row
    assert row["state"] == "TERMINAL" and row["returncode"] == 0 and row["passed"] is True
    assert row["cleanup_complete"] is True and row["orphaned_group"] is False and row["timed_out"] is False
    assert row["signals"] == [] and row["pid"] == row["process_group"] > 0
    start, finish = utc(row["started_utc"]), utc(row["finished_utc"])
    assert previous <= start <= finish <= end
    previous = finish
    budget = 180 if label in ("generate", "check") else 90 if label == "go-controls" else 15
    assert row["budget_seconds"] == budget and 0 <= row["elapsed_seconds"] <= budget
    assert abs((finish - start).total_seconds() - row["elapsed_seconds"]) < 0.05
    for stream in ("stdout", "stderr"):
        bound((g / (label + "." + stream + ".original")).read_bytes(), row[stream])

source_map = {
    "compiler": {"go.mod": "compiler-module", "go.sum": "compiler-sum", "tools/language-docs/main.go": "generator-main", "tools/language-docs/macro_metadata_test.go": "generator-macro-test", "tools/language-docs/p15_contract_test.go": "generator-contract-test", "docs/language-v2/actions-reference.md": "compiler-reference"},
    "docs": {".github/workflows/docs-smoke-test.yml": "docs-workflow", "scripts/smoke_test_snippets.py": "docs-smoke", "scripts/test_smoke_test_snippets.py": "docs-cache-test", "scripts/verify_generated_reference.py": "docs-driver", "fork-language/actions.md": "docs-reference"}}
tree_counts = {}
for role in ("compiler", "docs"):
    tree = api(role + "-tree")
    assert tree["truncated"] is False
    entries = sorted((item for item in tree["tree"] if item["type"] != "tree"), key=lambda item: item["path"].encode())
    expected_stage = b"".join((item["mode"] + " " + item["sha"] + " 0\t" + item["path"] + "\0").encode() for item in entries)
    expected_flags = b"".join(("H " + item["path"] + "\0").encode() for item in entries)
    tree_counts[role] = len(entries)
    for phase in ("before", "after"):
        state = report[phase][role]
        expected_head = COMPILER if role == "compiler" else DOCS
        assert state["head"] == expected_head and state["clean"] is True
        assert (g / (phase + "-" + role + "-head.stdout.original")).read_bytes() == (expected_head + "\n").encode()
        assert (g / (phase + "-" + role + "-root.stdout.original")).read_bytes() == (state["root"] + "\n").encode()
        assert not (g / (phase + "-" + role + "-status.stdout.original")).read_bytes()
        assert (g / (phase + "-" + role + "-stage.stdout.original")).read_bytes() == expected_stage
        assert (g / (phase + "-" + role + "-flags.stdout.original")).read_bytes() == expected_flags
        assert sha(expected_stage) == state["tracked_stage_sha256"] and sha(expected_flags) == state["tracked_flags_sha256"]
        assert set(state["files"]) == set(source_map[role])
        for path, label in source_map[role].items():
            bound(source_bytes[label], state["files"][path])
            assert state["files"][path]["git_blob"] == source_blobs[label]["git_blob"]
            assert any(item["path"] == path and item["sha"] == source_blobs[label]["git_blob"] for item in entries)

cache_before = (g / "before-compiler-cache-receipt.original.json").read_bytes()
assert cache_before == (g / "after-compiler-cache-receipt.original.json").read_bytes()
cache = strict(cache_before)
assert cache == report["before"]["cache"]["receipt"]
assert cache == {"formatVersion": 1, "compilerCommit": COMPILER, "compilerRepository": "https://github.com/davidpovarsky/cherri.git", "binarySha256": BINARY, "vcsModified": False}
bound(cache_before, report["before"]["cache"]["receipt_file"])
assert report["before"]["cache"]["binary"]["sha256"] == BINARY
for phase in ("before", "after"):
    assert (g / (phase + "-cache-1.stdout.original")).read_bytes() == (COMPILER + "\n").encode()
    assert not (g / (phase + "-cache-2.stdout.original")).read_bytes()
    assert (g / (phase + "-cache-3.stdout.original")).read_bytes() == b"https://github.com/davidpovarsky/cherri.git\n"
    stamp = (g / (phase + "-cache-4.stdout.original")).read_text()
    assert stamp.count("\tbuild\tvcs.revision=" + COMPILER + "\n") == 1
    assert stamp.count("\tbuild\tvcs.modified=false\n") == 1 and "vcs.modified=true" not in stamp
    assert processes[phase + "-cache-4"]["command"] == ["go", "version", "-m", report[phase]["cache"]["binary"]["path"]]
    assert read(g / (phase + "-source-identities.json")) == report[phase]

target = report["generated"]["path"]
pattern = "^(" + "|".join(PARENTS) + ")$"
commands = {"generate": ["go", "run", "-p=2", "./tools/language-docs", target], "check": ["go", "run", "-p=2", "./tools/language-docs", "--check", target], "go-controls": ["go", "test", "-p=2", "-count=1", "-json", "-timeout=60s", "./tools/language-docs", "-run", pattern]}
for label, command in commands.items():
    assert processes[label]["command"] == command and processes[label]["cwd"] == report["before"]["compiler"]["root"]
    assert not (g / (label + ".stderr.original")).read_bytes()
assert report["commands"] == {"generation": processes["generate"], "check": processes["check"], "go_controls": processes["go-controls"]}
generated = (g / "actions-reference.generated.md").read_bytes()
bound(generated, report["generated"])
assert len(FRONT) == 119 and source_bytes["docs-reference"].startswith(FRONT)
assert generated == source_bytes["compiler-reference"] == source_bytes["docs-reference"][119:]
native, macros = generated.split(b"## Compiler macros\n")
native_names = re.findall(rb"^### `([^`\n]+)`$", native, re.M)
macro_names = re.findall(rb"^### `([^`\n]+)`$", macros, re.M)
assert len(native_names) == 505 and len(macro_names) == 15 and len(set(native_names + macro_names)) == 520
assert b"**Total Actions:** 505  \n" in native and b"**Compiler Macros:** 15\n" in macros
assert report["reference"] == {"native_actions": 505, "compiler_macros": 15, "headings": 520, "frontmatter_bytes": 119, "complete_byte_equality": True, "reference_sha256": sha(generated)}
assert set(re.findall(rb"^func (Test\w+)\(t \*testing.T\)", source_bytes["generator-contract-test"] + source_bytes["generator-macro-test"], re.M)) == {name.encode() for name in PARENTS}
mutation_source = source_bytes["generator-contract-test"].split(b"mutations := []struct{ name, old, new string }{")[1].split(b"\n\t}", 1)[0]
assert tuple(name.decode() for name in re.findall(rb'\{"([a-z_]+)",', mutation_source)) == MUTATIONS
events = [strict(line) for line in (g / "go-controls.stdout.original").read_bytes().splitlines()]
started, passed = Counter(), Counter()
pkg_start = pkg_pass = 0
for event in events:
    assert event["Package"] == PACKAGE
    assert utc(processes["go-controls"]["started_utc"]) <= utc(event["Time"]) <= utc(processes["go-controls"]["finished_utc"])
    assert pkg_pass == 0
    action, name = event["Action"], event.get("Test")
    assert action in ("start", "run", "output", "pass")
    if name:
        assert name in TESTS and pkg_start == 1
        if action == "run":
            assert started[name] == passed[name] == 0
            started[name] += 1
        elif action == "pass":
            assert started[name] == 1 and passed[name] == 0
            assert all(passed[child] == 1 for child in TESTS if child.startswith(name + "/"))
            passed[name] += 1
        else:
            assert action == "output" and started[name] == 1 and passed[name] == 0
    elif action == "start":
        assert pkg_start == 0 and not started
        pkg_start += 1
    elif action == "pass":
        assert set(started) == set(passed) == TESTS and all(started[name] == passed[name] == 1 for name in TESTS)
        pkg_pass += 1
    else:
        assert action == "output" and pkg_start == 1
assert pkg_start == pkg_pass == 1 and len(started) == len(passed) == 12
assert set(report["go_events"]["run_once"]) == set(report["go_events"]["passed_once"]) == TESTS

log = (ROOT / "smoke-log.decoded-original.log").read_text()
for label in labels:
    endings = [strict(line.split("DOCS_GENERATOR_END ", 1)[1]) for line in log.splitlines() if "DOCS_GENERATOR_END " in line and '"label": "' + label + '"' in line]
    assert len(endings) == 1 and endings[0] == {key: processes[label][key] for key in ("label", "passed", "returncode", "timed_out", "elapsed_seconds")}
expected_cache = sorted(n.name for c in ast.parse(source_bytes["docs-cache-test"]).body if isinstance(c, ast.ClassDef) and c.name == "SmokeProductionTests" for n in c.body if isinstance(n, ast.FunctionDef) and n.name.startswith("test_"))
actual_cache = re.findall(r"(test_\w+) \(__main__\.SmokeProductionTests\.\w+\) \.\.\. ok", log)
assert len(expected_cache) == len(actual_cache) == 12 and sorted(actual_cache) == expected_cache
assert "Ran 12 tests in 28.798s" in log and re.search(r"Z OK\n", log)
witnesses = [strict(line.split("CACHE_SOURCE_WITNESS ", 1)[1]) for line in log.splitlines() if "CACHE_SOURCE_WITNESS " in line]
assert len(witnesses) == 18
leases = defaultdict(dict)
for witness in witnesses:
    if witness["event"] in ("acquire", "release"):
        assert witness["event"] not in leases[witness["case"]]
        leases[witness["case"]][witness["event"]] = witness
        state = witness["sourceState"]
        assert state["revision"] == COMPILER and state["status"] == "" and state["origin"] == "https://github.com/davidpovarsky/cherri.git"
        assert state["goModSha256"] == sha(source_bytes["compiler-module"])
        if witness["event"] == "acquire":
            assert witness["binarySha256"] == BINARY
assert len(leases) == 6 and all(set(pair) == {"acquire", "release"} and pair["acquire"]["sourceState"] == pair["release"]["sourceState"] for pair in leases.values())
assert Counter(w["event"] for w in witnesses)["same-byte-replacement-rejected"] == 2

snippet = read(ROOT / "14733852372.members/cherri-docs-evidence.json")
assert snippet["compilerCommit"] == COMPILER and snippet["binarySha256"] == BINARY and snippet["passed"] is True
documents = {"fork-language/actions.md": "docs-reference", "fork-language/guide.md": "docs-guide", "fork-language/migration.md": "docs-migration", "index.md": "docs-index", "language/functions.md": "docs-functions", "language/variables-constants-globals.md": "docs-variables"}
fences = re.compile(r"^```(?P<kind>cherri(?:-[a-z]+)?)\s*\r?\n(?P<code>.*?)^```\s*$", re.M | re.S)
blocks = {(path, index): match for path, label in documents.items() for index, match in enumerate(fences.finditer(source_bytes[label].decode()), 1)}
seen = set()
for record in snippet["records"]:
    path = record["file"].split("/cherrilang.org/cherrilang.org/", 1)[1]
    key = path, record["block"]
    assert key not in seen and key in blocks
    seen.add(key)
    match = blocks[key]
    code = match["code"].strip()
    assert record["sourceSha256"] == sha((code + ("\n" if record["executed"] else "")).encode())
    if record["executed"]:
        assert record["passed"] is True
        if record["classification"] == "runnable":
            assert record["checkExit"] == record["compileExit"] == 0 and re.fullmatch(r"[0-9a-f]{64}", record["unsignedSha256"])
        else:
            assert record["classification"] == "diagnostic" and record["expectedErrors"] == record["actualErrors"]
            assert record["checkExit"] != 0 and record["compileExit"] != 0
    else:
        assert record["classification"] in ("generated-signature", "cherri-legacy", "cherri-fragment")
assert seen == set(blocks) and len(seen) == 563
executed = [row for row in snippet["records"] if row["executed"]]
assert len(executed) == snippet["executed"] == 39 and snippet["referenceOnly"] == 524
assert Counter(row["classification"] for row in executed) == {"runnable": 36, "diagnostic": 3}

site_root = ROOT / "14733304387.members"
site, controls = read(site_root / "cherri-docs-site-evidence.json"), read(site_root / "cherri-docs-site-controls.json")
for value in (site, controls):
    assert value["docsCommit"] == DOCS and value["compilerCommit"] == COMPILER
assert site["sourceTreeClean"] is True and site["sitePublished"] is False
assert site["sourceReferenceSha256"] == sha(source_bytes["docs-reference"])
assert (site["nativeActionCount"], site["renderedReferenceSignatures"], site["searchEntries"], site["actionSearchEntries"], site["verifiedLocalLinks"], site["historicalSearchEntries"]) == (505, 520, 50, 21, 87, 0)
assert sha((site_root / "cherri-docs-site" / site["renderedActionPage"]).read_bytes()) == site["renderedActionPageSha256"]
assert sha((site_root / "cherri-docs-site/assets/js/search-data.json").read_bytes()) == site["searchIndexSha256"]
assert (controls["passed"], controls["failed"], controls["skipped"]) == (6, 0, 0) and controls["artifactsRestoredExactly"] is True
assert len(controls["controls"]) == len({row["name"] for row in controls["controls"]}) == 6 and all(row["rejected"] is True and row["diagnostic"] for row in controls["controls"])

result = {"schema": "cherri.d10-generation-independent-intake/v1", "status": "PASS", "read_at": datetime.now(timezone.utc).isoformat(), "run": RUN, "attempt": 1, "docs_source": DOCS, "compiler_source": COMPILER, "linux_binary_sha256": BINARY,
          "generation": {"elapsed_seconds": processes["generate"]["elapsed_seconds"], "check_elapsed_seconds": processes["check"]["elapsed_seconds"], "go_elapsed_seconds": processes["go-controls"]["elapsed_seconds"], "reference_bytes": len(generated), "reference_sha256": sha(generated), "complete_generated_canonical_docs_body_equality": True, "native_actions": 505, "macros": 15, "headings": 520},
          "go": {"parents": list(PARENTS), "mutations": list(MUTATIONS), "run_once": sorted(started), "pass_once": sorted(passed), "fail": 0, "skip": 0, "raw_events": len(events), "raw_sha256": sha((g / "go-controls.stdout.original").read_bytes())},
          "source": {"before_after_identical": True, "git_tree_index_entries": tree_counts, "direct_generation_witnesses": 11, "all_raw_process_receipts_reconciled": len(processes), "source_bindings": source_blobs},
          "cache": {"actual_controls": 12, "elapsed_seconds": 28.798, "witnesses": 18, "clean_acquire_release_pairs": 6, "same_byte_replacement_controls": 2, "binary_receipt_before_after_identical": True},
          "smoke": {"actual_executions": 39, "runnable": 36, "diagnostic": 3, "reference_only_unexecuted": 524, "all563_source_block_hashes_reconciled": True},
          "site": {"rendered_signatures": 520, "search_entries": 50, "controls_passed": 6, "artifacts_restored_exactly": True, "published": False}, "artifacts": artifact_rows,
          "scope": "Original single GitHub source generation/check, Go controls, snippet/cache and built-site evidence. No local re-execution, Windows binary equivalence, Pages promotion, Apple runtime, installed-consumer deployment or full179 acceptance."}
(ROOT / "independent-intake.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ("status", "run", "docs_source", "compiler_source", "generation", "go", "cache", "smoke", "site")}, indent=2))
