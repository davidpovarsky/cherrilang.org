import json,hashlib,subprocess,os,datetime
from pathlib import Path
D=Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126")
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/reference-contract-green-01")
E.mkdir(exist_ok=False);(E/"owner.original.py").write_text(Path(__file__).read_text())
P=D/"scripts/verify_generated_reference.py";old=P.read_text()
assert hashlib.sha256(P.read_bytes()).hexdigest()=="1c3cbfb0ebe8f98426423e7c3a40c9fbad759c8025b80041a7349dd8798cc0ba"
(E/"verifier-before.original.py").write_text(old)
marker='TEST_PATTERN = "^(" + "|".join(PARENTS) + ")$"\n'
names='''EXPECTED_MACROS = (
    b"cache", b"debugAssert", b"debugClearLogs", b"debugExport", b"debugExportTrace",
    b"debugFinish", b"debugLog", b"debugLogPrevious", b"debugShowLogs",
    b"debugStartTimer", b"debugStopTimer", b"debugTrace", b"debugTraceEvent",
    b"measure", b"paginate", b"require",
)
'''
assert old.count(marker)==1
new=old.replace(marker,marker+names)
a='''    require(len(native_names) == 505 and len(macro_names) == 15 and
            len(set(native_names + macro_names)) == 520, "reference heading inventory differs")
    require(b"**Total Actions:** 505  \\n" in native and b"**Compiler Macros:** 15\\n" in macros,
            "reference count headers differ")
    return {"native_actions": 505, "compiler_macros": 15, "headings": 520,
'''
b='''    require(len(native_names) == 505 and macro_names == list(EXPECTED_MACROS) and
            len(set(native_names + macro_names)) == 505 + len(EXPECTED_MACROS),
            "reference heading inventory differs")
    require(b"**Total Actions:** 505  \\n" in native and b"**Compiler Macros:** 16\\n" in macros,
            "reference count headers differ")
    return {"native_actions": 505, "compiler_macros": len(EXPECTED_MACROS),
            "headings": 505 + len(EXPECTED_MACROS),
'''
assert new.count(a)==1
new=new.replace(a,b);compile(new,str(P),"exec");P.write_text(new);os.chown(P,1001,1001)
(E/"verifier-after.original.py").write_text(new)
T=D/"scripts/test_generated_reference_contract.py"
assert hashlib.sha256(T.read_bytes()).hexdigest()=="4faf6ddd441b05824e72d0cd2e2332ed3569610f4f7c8a9036dc2fb62255e128"
fixture=E.parent/"reference-contract-red-01/canonical-reference.original.md"
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE="1",CHERRI_REFERENCE_FIXTURE=str(fixture))
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(["python3","-B",str(T)],cwd=D,env=env,capture_output=True,timeout=30)
(E/"stdout.original.bin").write_bytes(r.stdout);(E/"stderr.original.bin").write_bytes(r.stderr)
rec={"status":"PASS" if r.returncode==0 else "FAIL","startedAt":started,"finishedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exitCode":r.returncode,"testSHA256":hashlib.sha256(T.read_bytes()).hexdigest(),"testBytesIdenticalToRED":True,"beforeVerifierSHA256":hashlib.sha256(old.encode()).hexdigest(),"afterVerifierSHA256":hashlib.sha256(P.read_bytes()).hexdigest(),"fixtureSHA256":hashlib.sha256(fixture.read_bytes()).hexdigest(),"scope":"Six actual Python test methods: exact16 ordered macro names/505 native headings, twelve causal mutations, complete three-way bytes and original frontmatter. No Go/generation/site/native run.","macroInventory":["cache","debugAssert","debugClearLogs","debugExport","debugExportTrace","debugFinish","debugLog","debugLogPrevious","debugShowLogs","debugStartTimer","debugStopTimer","debugTrace","debugTraceEvent","measure","paginate","require"]}
raw=(json.dumps(rec,indent=2)+"\n").encode();(E/"result.original.json").write_bytes(raw);print(json.dumps({"path":str(E/"result.original.json"),"sha256":hashlib.sha256(raw).hexdigest(),**rec,"stderr":r.stderr.decode()}))
