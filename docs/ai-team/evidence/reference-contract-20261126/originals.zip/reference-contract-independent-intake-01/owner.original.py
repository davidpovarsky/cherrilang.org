import pathlib,json,hashlib,ast,re,subprocess,os,datetime,traceback
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126')
D=pathlib.Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126')
O=E/'reference-contract-independent-intake-01';O.mkdir(exist_ok=False)
(O/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
h=lambda b:hashlib.sha256(b).hexdigest()
r={'schema':'cherri-reference-contract-independent-intake/1','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reexecution':False}
try:
 required={'reference-contract-red-01/result.original.json':'abaafae8cf98f80c18a3ffd1c6e243d0745b941f5ed566645f8f9d75f19b5d01','reference-contract-green-01/result.original.json':'d19cd595dce34e534afec129a71e71de1fccb49fecff269f60e58031f38ef34f','reference-contract-checkpoint-01/result.original.json':'3eab36de34a2bc00ba6998faeb80cba0828718b5c63a2f1c25ed3da132efa813','workflow-connector-publication-01/result.original.json':'5c542f2de337e08739986b472e6e31e0d89377d38ee74b18ecf39ce106b82866'}
 for name,digest in required.items():assert h((E/name).read_bytes())==digest,name
 red=json.loads((E/'reference-contract-red-01/result.original.json').read_text())
 green=json.loads((E/'reference-contract-green-01/result.original.json').read_text())
 assert red['status']=='EXPECTED_RED' and red['exitCode']==1
 assert green['status']=='PASS' and green['exitCode']==0 and green['testBytesIdenticalToRED']
 test=(E/'reference-contract-red-01/test-source.original.py').read_bytes()
 assert test==(D/'scripts/test_generated_reference_contract.py').read_bytes()
 assert h(test)==red['testSHA256']==green['testSHA256']=='4faf6ddd441b05824e72d0cd2e2332ed3569610f4f7c8a9036dc2fb62255e128'
 old=(E/'reference-contract-red-01/verifier-before.original.py').read_bytes()
 qualified=(E/'reference-contract-green-01/verifier-after.original.py').read_bytes()
 current=(D/'scripts/verify_generated_reference.py').read_bytes()
 assert h(old)==red['verifierSHA256']==green['beforeVerifierSHA256']
 assert h(qualified)==green['afterVerifierSHA256']
 assert h(current)=='4f5fc018e69858b9b1532f9d6fe8a4ae535aa59fb7dba2e8070ae6e92ff64954'
 def without_inventory(b):
  t=ast.parse(b)
  t.body=[n for n in t.body if not(isinstance(n,ast.Assign) and any(isinstance(z,ast.Name) and z.id=='DOCS_FILES' for z in n.targets))]
  return ast.dump(t,include_attributes=False)
 assert without_inventory(qualified)==without_inventory(current),'noninventory postqualification delta'
 def inventory(b):
  return next(ast.literal_eval(n.value) for n in ast.parse(b).body if isinstance(n,ast.Assign) and any(isinstance(z,ast.Name) and z.id=='DOCS_FILES' for z in n.targets))
 oldinv=inventory(qualified);newinv=inventory(current)
 assert tuple(x for x in newinv if x!='scripts/test_generated_reference_contract.py')==tuple(oldinv)
 fixture=(E/'reference-contract-red-01/canonical-reference.original.md').read_bytes()
 assert h(fixture)==red['fixtureSHA256']==green['fixtureSHA256']
 parent=next(n for n in ast.parse(test).body if isinstance(n,ast.ClassDef))
 methods=sorted(n.name for n in parent.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
 assert len(methods)==6
 stderr=(E/'reference-contract-green-01/stderr.original.bin').read_text()
 observed=re.findall(r'^(test_\w+) \(__main__\.GeneratedReferenceContractTests\.\w+\) \.\.\. ok$',stderr,re.M)
 assert observed==methods and re.search(r'Ran 6 tests in [0-9.]+s\s+OK\s*$',stderr)
 assert not (E/'reference-contract-green-01/stdout.original.bin').read_bytes()
 faults=['macro_foreign','macro_duplicate','macro_missing','macro_reordered','native_missing','native_duplicate','duplicate_section','old_macro_count','wrong_native_count','compiler_reference_drift','docs_reference_drift','frontmatter_drift']
 assert len(faults)==12
 workflow=(D/'.github/workflows/docs-smoke-test.yml').read_bytes()
 assert h(workflow)=='3a6a3379cb1aee58f24376544e9cc3ed1c3b720bb431d6f9fa368b181dc8b242'
 assert workflow.count(b'run: python3 scripts/test_generated_reference_contract.py')==1
 source=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(D),'rev-parse','HEAD'],capture_output=True,check=True,text=True).stdout.strip()
 assert source=='5c83558695bfd8ebe3c3ece253f1eefd267f4418'
 r.update(status='PASS_ORIGINALS_AND_PUBLISHED_SOURCE',source=source,originalReceipts=required,testSHA256=h(test),qualifiedVerifierSHA256=h(qualified),publishedVerifierSHA256=h(current),fixtureSHA256=h(fixture),exactPassingMethods=methods,causalMutations=faults,productionASTIdenticalExceptAddedSourceInventory=True,workflowFixedStepCount=1,scope='Original Python reference inventory/byte-comparison evidence only. Existing committed canonical reference is a real fixture, not a new generator output. No Go, full documentation CI, new compiler pins, site publication or runtime acceptance.')
except Exception as e:
 r.update(status='FAILED',error=str(e),traceback=traceback.format_exc())
finally:
 r['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 out=O/'result.original.json';out.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'path':str(out),'sha256':h(out.read_bytes()),'status':r['status'],'error':r.get('error'),'source':r.get('source')}))
 if r['status']=='FAILED':raise SystemExit(1)
