import pathlib,subprocess,hashlib,json,os,datetime,traceback
W=pathlib.Path('/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126')
E=pathlib.Path('/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/workflow-connector-publication-01')
E.mkdir(parents=True,exist_ok=False)
(E/'owner.original.py').write_bytes(pathlib.Path(__file__).read_bytes())
API=json.loads("{\"content\":[{\"type\":\"text\",\"text\":\"Action completed.\"}],\"structuredContent\":{\"commit_sha\":\"8fba3d76bd7de9ad81f7e2dc8302f936b9fd9121\",\"content_sha\":\"95ade15742c04957805ef0a102763cc8a5d6bd5a\"},\"isError\":false}")
BEFORE=json.loads("{\"content\":[{\"type\":\"text\",\"text\":\"Action completed.\"}],\"structuredContent\":{\"content\":\"name: Docs Snippet Smoke Test\\n\\non:\\n  push:\\n    branches:\\n      - \\\"main\\\"\\n      - \\\"agent/**\\\"\\n  pull_request:\\n  workflow_dispatch:\\n\\npermissions:\\n  contents: read\\n\\nconcurrency:\\n  group: docs-smoke-test-${{ github.ref }}\\n  cancel-in-progress: true\\n\\njobs:\\n  smoke-test-snippets:\\n    runs-on: ubuntu-latest\\n    timeout-minutes: 20\\n    env:\\n      PYTHONDONTWRITEBYTECODE: \\\"1\\\"\\n      GOMAXPROCS: \\\"2\\\"\\n      GOFLAGS: \\\"-p=2\\\"\\n    steps:\\n      - name: Checkout cherrilang.org\\n        uses: actions/checkout@v4\\n\\n      - name: Set up Go\\n        uses: actions/setup-go@v5\\n        with:\\n          go-version: \\\"1.24\\\"\\n\\n      - name: Set up Python\\n        uses: actions/setup-python@v5\\n        with:\\n          python-version: \\\"3.12\\\"\\n\\n      - name: Run standalone docs snippet smoke test against pinned Cherri compiler\\n        env:\\n          CHERRI_SMOKE_CACHE_DIR: ${{ runner.temp }}/cherri-docs-compiler\\n          GOCACHE: ${{ runner.temp }}/cherri-docs-go-build\\n        run: python3 scripts/smoke_test_snippets.py --evidence-out \\\"$RUNNER_TEMP/cherri-docs-evidence.json\\\"\\n\\n      - name: Verify real compiler cache provenance and negative examples\\n        env:\\n          CHERRI_SMOKE_TEST_CACHE: ${{ runner.temp }}/cherri-docs-compiler\\n        run: python3 scripts/test_smoke_test_snippets.py\\n\\n      - name: Regenerate and verify the pinned action reference\\n        env:\\n          CHERRI_SMOKE_CACHE_DIR: ${{ runner.temp }}/cherri-docs-compiler\\n          GOCACHE: ${{ runner.temp }}/cherri-docs-go-build\\n          GIT_NO_REPLACE_OBJECTS: \\\"1\\\"\\n        run: >-\\n          python3 scripts/verify_generated_reference.py\\n          --cache \\\"$CHERRI_SMOKE_CACHE_DIR\\\"\\n          --docs-sha \\\"$GITHUB_SHA\\\"\\n          --output-dir \\\"$RUNNER_TEMP/cherri-docs-generation\\\"\\n\\n      - name: Retain generator originals and source receipts\\n        if: always()\\n        uses: actions/upload-artifact@v4\\n        with:\\n          name: docs-generator-evidence\\n          path: ${{ runner.temp }}/cherri-docs-generation\\n          if-no-files-found: warn\\n\\n      - name: Retain bounded documentation evidence\\n        if: always()\\n        uses: actions/upload-artifact@v4\\n        with:\\n          name: docs-snippet-evidence\\n          path: ${{ runner.temp }}/cherri-docs-evidence.json\\n          if-no-files-found: warn\\n\\n  build-site:\\n    name: Build documentation and search index\\n    runs-on: ubuntu-latest\\n    env:\\n      BUNDLE_FROZEN: \\\"true\\\"\\n      PYTHONDONTWRITEBYTECODE: \\\"1\\\"\\n    steps:\\n      - name: Checkout cherrilang.org\\n        uses: actions/checkout@v4\\n\\n      - name: Set up locked Ruby toolchain\\n        uses: ruby/setup-ruby@4a9ddd6f338a97768b8006bf671dfbad383215f4\\n        with:\\n          ruby-version: \\\"3.3\\\"\\n          bundler: \\\"2.5.11\\\"\\n          bundler-cache: false\\n\\n      - name: Install locked site dependencies\\n        env:\\n          BUNDLE_PATH: ${{ runner.temp }}/cherri-docs-bundle\\n        run: bundle install --jobs 2 --retry 3\\n\\n      - name: Build Jekyll site\\n        env:\\n          BUNDLE_PATH: ${{ runner.temp }}/cherri-docs-bundle\\n          JEKYLL_ENV: production\\n        run: bundle exec jekyll build --disable-disk-cache --baseurl \\\"/cherrilang.org\\\" --destination \\\"$RUNNER_TEMP/cherri-docs-site\\\"\\n\\n      - name: Verify rendered action reference and generated search\\n        run: python3 scripts/verify_site_artifacts.py --site \\\"$RUNNER_TEMP/cherri-docs-site\\\" --evidence-out \\\"$RUNNER_TEMP/cherri-docs-site-evidence.json\\\"\\n\\n      - name: Reject corrupted real site and search artifacts\\n        run: python3 scripts/test_site_artifacts.py --site \\\"$RUNNER_TEMP/cherri-docs-site\\\" --evidence-out \\\"$RUNNER_TEMP/cherri-docs-site-controls.json\\\"\\n\\n      - name: Retain built site and verification evidence\\n        if: always()\\n        uses: actions/upload-artifact@v4\\n        with:\\n          name: docs-built-site\\n          path: |\\n            ${{ runner.temp }}/cherri-docs-site\\n            ${{ runner.temp }}/cherri-docs-site-evidence.json\\n            ${{ runner.temp }}/cherri-docs-site-controls.json\\n          if-no-files-found: warn\\n\",\"encoding\":\"utf-8\",\"sha\":\"e40d9dc0f678550e42c996400e7e609a3f9f769f\",\"display_url\":\"https://github.com/davidpovarsky/cherrilang.org/blob/agent/cherri-p10r15-docs-final-alignment-20261126/.github/workflows/docs-smoke-test.yml\",\"display_title\":\"docs-smoke-test.yml\"},\"isError\":false}")
(E/'connector-update.original.json').write_text(json.dumps(API,ensure_ascii=False,indent=2)+'\n')
(E/'connector-before.original.json').write_text(json.dumps(BEFORE,ensure_ascii=False,indent=2)+'\n')
BR='agent/cherri-p10r15-docs-final-alignment-20261126'
commands=[]
def git(label,*a,timeout=30):
 p=subprocess.run(['/usr/sbin/runuser','-u','ubuntu','--','git','-C',str(W),*a],capture_output=True,timeout=timeout,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
 (E/(label+'.stdout.original.bin')).write_bytes(p.stdout);(E/(label+'.stderr.original.bin')).write_bytes(p.stderr)
 commands.append({'label':label,'args':list(a),'exitCode':p.returncode,'stdoutSHA256':hashlib.sha256(p.stdout).hexdigest(),'stderrSHA256':hashlib.sha256(p.stderr).hexdigest()})
 if p.returncode: raise RuntimeError(label+' exit '+str(p.returncode)+': '+p.stderr.decode('utf-8','replace')[-1500:])
 return p.stdout.decode().strip()
r={'schema':'cherri-docs-workflow-connector-publication/1','startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':commands}
try:
 assert git('before-head','rev-parse','HEAD')=='c9d04585efb5d3798302b2e421bf4a0142d3d950'
 assert not git('before-status','status','--porcelain=v1')
 assert git('before-tree','rev-parse','HEAD^{tree}')=='f9b41b4c57416b19dd24ce5175b05d0a79d8f653'
 git('fetch','fetch','origin',BR,timeout=35)
 fetched=git('fetched-head','rev-parse','FETCH_HEAD');assert fetched=='8fba3d76bd7de9ad81f7e2dc8302f936b9fd9121',fetched
 assert git('api-parent','rev-parse',fetched+'^')=='3984bbbb19e8a7c0f89cdb166e9bab4e395f6969'
 assert git('api-files','diff-tree','--no-commit-id','--name-only','-r',fetched)=='.github/workflows/docs-smoke-test.yml'
 workflow=git('api-workflow','show',fetched+':.github/workflows/docs-smoke-test.yml')+'\n'
 assert workflow==(W/'.github/workflows/docs-smoke-test.yml').read_text()
 git('merge','-c','user.name=David Povarsky','-c','user.email=davidpovarsky@users.noreply.github.com','merge','--no-ff',fetched,'-m','docs: join authorized workflow publication and reference controls [skip ci]')
 r['head']=git('after-head','rev-parse','HEAD')
 r['tree']=git('after-tree','rev-parse','HEAD^{tree}');assert r['tree']=='f9b41b4c57416b19dd24ce5175b05d0a79d8f653'
 r['parents']=git('after-parents','show','-s','--format=%P','HEAD').split()
 assert r['parents']==['c9d04585efb5d3798302b2e421bf4a0142d3d950',fetched]
 assert not git('after-status','status','--porcelain=v1')
 git('push','-c','credential.helper=','-c','credential.helper=!gh auth git-credential','push','origin',BR,timeout=35)
 r['remote']=git('remote','ls-remote','--heads','origin',BR).split()[0];assert r['remote']==r['head']
 r['status']='PUBLISHED_EXACT_MERGE_TREE'
except Exception as e:
 r['status']='FAILED';r['error']=str(e);r['traceback']=traceback.format_exc()
finally:
 r['endedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 out=E/'result.original.json';out.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),**{k:v for k,v in r.items() if k not in ('commands','traceback')}}))
 if r['status']=='FAILED':raise SystemExit(1)
