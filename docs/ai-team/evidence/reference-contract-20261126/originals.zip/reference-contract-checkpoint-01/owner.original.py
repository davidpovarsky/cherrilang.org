import json,subprocess,hashlib,os
from pathlib import Path
D=Path("/mnt/development/projects/worktrees/cherrilang-p10r15-docs-final-alignment-20261126")
E=Path("/mnt/development/projects/evidence/cherri-p10r15-consumer-final-alignment-20261126/reference-contract-checkpoint-01");E.mkdir(exist_ok=False);(E/"owner.original.py").write_text(Path(__file__).read_text())
W=D/".github/workflows/docs-smoke-test.yml";before=W.read_text()
needle="      - name: Retain generator originals and source receipts\n"
insert="      - name: Verify exact reference inventory and causal corruption controls\n        run: python3 scripts/test_generated_reference_contract.py\n\n"
assert before.count(needle)==1;W.write_text(before.replace(needle,insert+needle));os.chown(W,1001,1001)
P=D/"scripts/verify_generated_reference.py";text=P.read_text()
old='    "scripts/test_smoke_test_snippets.py", "scripts/verify_generated_reference.py",\n'
new=old+'    "scripts/test_generated_reference_contract.py",\n'
assert text.count(old)==1;P.write_text(text.replace(old,new))
def git(*a):
 r=subprocess.run(["/usr/sbin/runuser","-u","ubuntu","--","git","-C",str(D),*a],capture_output=True,text=True,timeout=60)
 assert r.returncode==0,(a,r.stdout,r.stderr);return r.stdout.strip()
assert git("rev-parse","HEAD")=="3984bbbb19e8a7c0f89cdb166e9bab4e395f6969"
paths=["scripts/verify_generated_reference.py","scripts/test_generated_reference_contract.py",".github/workflows/docs-smoke-test.yml"]
assert set(git("diff","--name-only").splitlines())|set(git("ls-files","--others","--exclude-standard").splitlines())==set(paths)
git("diff","--check")
diff=subprocess.check_output(["/usr/sbin/runuser","-u","ubuntu","--","git","-C",str(D),"diff","--binary"]);(E/"source.diff.original.patch").write_bytes(diff)
# Parse syntax and workflow without executing producers or changing compiler pins.
import ast,yaml
ast.parse(P.read_text());ast.parse((D/"scripts/test_generated_reference_contract.py").read_text())
workflow=yaml.safe_load(W.read_text());assert any(s.get("run")=="python3 scripts/test_generated_reference_contract.py" for s in workflow["jobs"]["smoke-test-snippets"]["steps"])
git("add","--",*paths)
out=git("-c","user.name=David Povarsky","-c","user.email=davidpovarsky@users.noreply.github.com","commit","-m","docs(ci): bind the canonical16 macro inventory with causal controls [skip ci]");(E/"commit.stdout.original.txt").write_text(out+"\n")
head=git("rev-parse","HEAD");branch=git("branch","--show-current")
r=subprocess.run(["/usr/sbin/runuser","-u","ubuntu","--","git","-C",str(D),"-c","credential.helper=","-c","credential.helper=!gh auth git-credential","push","origin",branch],capture_output=True,timeout=60)
(E/"push.stdout.original.bin").write_bytes(r.stdout);(E/"push.stderr.original.bin").write_bytes(r.stderr)
remote=git("ls-remote","--heads","origin","refs/heads/"+branch)
receipt={"status":"PUBLISHED" if r.returncode==0 and remote.split()[0]==head else "COMMITTED_PUSH_BLOCKED","head":head,"tree":git("rev-parse","HEAD^{tree}"),"branch":branch,"clean":not git("status","--porcelain","--untracked-files=all"),"pushExitCode":r.returncode,"remote":remote,"files":[{"path":p,"sha256":hashlib.sha256((D/p).read_bytes()).hexdigest()} for p in paths],"qualifiedPythonSource":"ee339f299b29c72aec319e293a1f8b950cfc736f1b969d4db803bbbfba53d74d","postQualificationChange":"Source-file inventory adds the exact new Python test and fixed workflow step; runtime reference function unchanged.","notYetFinal":"Compiler/reference pins intentionally unchanged pending actual canonical generation."}
b=(json.dumps(receipt,indent=2)+"\n").encode();(E/"result.original.json").write_bytes(b);print(json.dumps({"path":str(E/"result.original.json"),"sha256":hashlib.sha256(b).hexdigest(),**receipt,"pushStderr":r.stderr.decode()}))
