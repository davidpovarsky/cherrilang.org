import pathlib,subprocess,json,datetime,time,sys,hashlib
e=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-9c8daf72-20261121")
original=e/"source-build-and-generation.py"
assert hashlib.sha256(original.read_bytes()).hexdigest()=="ae78c04265c72659b63ff80fcdae06c54a8fa3853125ff566e0c8f9cafbab8bb"
text=original.read_text(encoding="utf-8")
old='''        assert not SOURCE.exists(),"owned source checkout must be absent"
        SOURCE.mkdir()
        git("01-init",["init"])
        git("02-lf",["config","core.autocrlf","false"])
        git("03-origin",["remote","add","origin",REPO])
        git("04-fetch",["fetch","--depth=1",str(SEED),SHA],budget=180)
        git("05-checkout",["checkout","--detach",SHA],budget=180)
'''
assert text.count(old)==1
text=text.replace(old,'''        assert SOURCE.is_dir(),"second attempt must reuse the exact original clean checkout"
        assert git("01-existing-lf",["config","--get","core.autocrlf"]).decode().strip()=="false"
''')
assert text.count('OUT=BASE/(args.phase+"-execution")')==1
text=text.replace('OUT=BASE/(args.phase+"-execution")','OUT=BASE/(args.phase+"-execution-retry-2")')
assert text.count('BASE/"build-execution/build-report.json"')==1
text=text.replace('BASE/"build-execution/build-report.json"','BASE/"build-execution-retry-2/build-report.json"')
compile(text,"source-build-and-generation-retry-2.py","exec")
script=e/"source-build-and-generation-retry-2.py"
assert not script.exists()
script.write_text(text,encoding="utf-8",newline="\n")
assert not (e/"build-execution-retry-2").exists() and not (e/"generation-execution-retry-2").exists()
guard=e/"assigned-slot-execution-retry-2";guard.mkdir()
(guard/"submitted-launcher.py").write_bytes(pathlib.Path(__file__).read_bytes())
receipt={"compilerCandidate":"9c8daf721aa241127df8d1e3f91bbadf90110e73","attempt":2,
"priorAttempt":"assigned-slot-execution/receipt.json","priorTimeoutRetained":True,
"sameCheckout":True,"sameBuildFlags":["-p=2","-buildvcs=true"],"individualBuildBudgetSeconds":180,
"launcherSha256":hashlib.sha256(script.read_bytes()).hexdigest(),
"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"phases":[],"publication":False,"finalPinsChanged":False}
def save(): (guard/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
save()
for phase,budget in [("build",660),("generation",480)]:
 out=guard/(phase+".stdout");err=guard/(phase+".stderr")
 row={"phase":phase,"command":[sys.executable,"-B",str(script),"--phase",phase],"processBudget":budget,
      "startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 receipt["phases"].append(row);save();start=time.monotonic()
 with out.open("xb") as stdout,err.open("xb") as stderr:
  p=subprocess.Popen(row["command"],stdout=stdout,stderr=stderr);row["pid"]=p.pid;save()
  try:row["exitCode"]=p.wait(timeout=budget);row["timedOut"]=False
  except subprocess.TimeoutExpired:
   row["timedOut"]=True
   stop=subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=20)
   (guard/(phase+".owned-stop.stdout")).write_bytes(stop.stdout)
   (guard/(phase+".owned-stop.stderr")).write_bytes(stop.stderr)
   row["exitCode"]=p.wait(timeout=20)
 row.update(elapsedSeconds=round(time.monotonic()-start,6),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            stdoutSha256=hashlib.sha256(out.read_bytes()).hexdigest(),stderrSha256=hashlib.sha256(err.read_bytes()).hexdigest())
 save()
 if row["exitCode"] or row["timedOut"]:
  receipt["status"]="FAILED";receipt["finishedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
  print(json.dumps(receipt,indent=2));sys.exit(1)
receipt["status"]="PASSED_BUILD_AND_GENERATION";receipt["finishedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(receipt,indent=2))
