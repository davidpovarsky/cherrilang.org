import argparse,datetime,hashlib,json,os,pathlib,re,shutil,subprocess,sys,time
BASE=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-source-9c8daf72-exact-20261121")
SEED=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-completion-r4-20261120")
SHA="9c8daf721aa241127df8d1e3f91bbadf90110e73"
REPO="https://github.com/davidpovarsky/cherri.git"
parser=argparse.ArgumentParser()
parser.add_argument("--phase",choices=["build","generation"],required=True)
args=parser.parse_args()
OUT=BASE/(args.phase+"-execution")
OUT.mkdir()
(OUT/"submitted-script.py").write_bytes(pathlib.Path(__file__).read_bytes())
receipts=[]
def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
    h=hashlib.sha256()
    with pathlib.Path(p).open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):
            h.update(block)
    return h.hexdigest()
def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8")
def run(name,argv,cwd,budget=180):
    raw=OUT/(name+".stdout")
    err=OUT/(name+".stderr")
    rec={"name":name,"command":[str(x) for x in argv],"cwd":str(cwd),"budgetSeconds":budget,"startedAt":utc()}
    started=time.monotonic()
    with raw.open("xb") as stdout,err.open("xb") as stderr:
        proc=subprocess.Popen(rec["command"],cwd=cwd,stdout=stdout,stderr=stderr)
        rec["pid"]=proc.pid
        write("active-process.json",rec)
        try:
            rec["exitCode"]=proc.wait(timeout=budget)
            rec["timedOut"]=False
        except subprocess.TimeoutExpired:
            rec["timedOut"]=True
            stop=subprocess.run(["taskkill","/PID",str(proc.pid),"/T","/F"],capture_output=True,timeout=20)
            (OUT/(name+".owned-timeout-stop.stdout")).write_bytes(stop.stdout)
            (OUT/(name+".owned-timeout-stop.stderr")).write_bytes(stop.stderr)
            rec["ownedStopExitCode"]=stop.returncode
            rec["exitCode"]=proc.wait(timeout=20)
    rec.update(finishedAt=utc(),elapsedSeconds=round(time.monotonic()-started,6),
               stdoutPath=raw.name,stdoutSha256=digest(raw),stdoutBytes=raw.stat().st_size,
               stderrPath=err.name,stderrSha256=digest(err),stderrBytes=err.stat().st_size)
    receipts.append(rec)
    write("processes.json",receipts)
    if rec["timedOut"] or rec["exitCode"]!=0:
        raise RuntimeError(name+" failed; original outputs and receipt retained")
    return raw.read_bytes()
def git(name,argv,cwd=SOURCE,budget=60):
    return run(name,["git","--no-replace-objects",*argv],cwd,budget)
def clean(label):
    assert git(label+"-head",["rev-parse","HEAD"]).decode().strip()==SHA
    assert not git(label+"-status",["status","--porcelain=v1","--untracked-files=all","--ignored=matching"]).strip()
    assert git(label+"-origin",["remote","get-url","origin"]).decode().strip()==REPO
def identity(name,path):
    raw=run(name+"-identity",["go","version","-m",str(path)],SOURCE,30).decode("utf-8")
    assert re.search(r"\bbuild\s+vcs\.revision="+re.escape(SHA)+r"\s*$",raw,re.M)
    assert re.search(r"\bbuild\s+vcs\.modified=false\s*$",raw,re.M)
    return {"path":str(path),"bytes":path.stat().st_size,"sha256":digest(path),"vcsRevision":SHA,"vcsModified":False}
started=utc()
write("start.json",{"phase":args.phase,"source":str(SOURCE),"compilerCommit":SHA,"startedAt":started,
                   "candidateOnly":True,"publicationAuthorizedByThisScript":False,
                   "goConcurrency":2,"freeBytesBefore":shutil.disk_usage(BASE).free})
try:
    if args.phase=="build":
        assert not SOURCE.exists(),"owned source checkout must be absent"
        SOURCE.mkdir()
        git("01-init",["init"])
        git("02-lf",["config","core.autocrlf","false"])
        git("03-origin",["remote","add","origin",REPO])
        git("04-fetch",["fetch","--depth=1",str(SEED),SHA],budget=180)
        git("05-checkout",["checkout","--detach",SHA],budget=180)
        clean("06-before")
        compiler=OUT/"compiler.exe"
        migrator=OUT/"cherri-migrate.exe"
        run("07-compiler-build",["go","build","-p=2","-buildvcs=true","-o",str(compiler),"."],SOURCE,180)
        run("08-migrator-build",["go","build","-p=2","-buildvcs=true","-o",str(migrator),"./cmd/cherri-migrate"],SOURCE,180)
        binaries={"compiler":identity("09-compiler",compiler),"migrator":identity("10-migrator",migrator)}
        cap=run("11-capabilities",[str(compiler),"--capabilities-json"],SOURCE,30)
        capabilities=json.loads(cap)
        clean("12-after")
        write("build-report.json",{"compilerCommit":SHA,"source":str(SOURCE),"startedAt":started,"finishedAt":utc(),
                                 "binaries":binaries,"capabilities":capabilities,"sourceCleanBeforeAndAfter":True,
                                 "candidateOnly":True,"docsPublished":False,"freeBytesAfter":shutil.disk_usage(BASE).free})
        print(json.dumps({"phase":"build","compilerCommit":SHA,"binaries":binaries,"sourceClean":True}))
    else:
        build=json.loads((BASE/"build-execution/build-report.json").read_text(encoding="utf-8"))
        assert build["compilerCommit"]==SHA and build["source"]==str(SOURCE)
        for name,info in build["binaries"].items():
            assert digest(info["path"])==info["sha256"]
        clean("01-before")
        target=OUT/"actions-reference.md"
        run("02-generate",["go","run","-p=2","./tools/language-docs",str(target)],SOURCE,180)
        run("03-generated-check",["go","run","-p=2","./tools/language-docs","--check",str(target)],SOURCE,180)
        parents=["TestGeneratedReferenceIncludesSeparateMacroContracts","TestP15D01PrimaryParameterContract",
                 "TestP15D01AllGeneratedSignaturesAndCategories","TestP15D01CheckGateProducesAndRejectsFaults"]
        mutations=["optional_primary","typed_default","callable_identity","wire_key","return_type","macro_identity","missing_category","extra_section"]
        expected=set(parents+[parents[-1]+"/"+x for x in mutations])
        raw=run("04-generation-controls",["go","test","-p=2","-count=1","-json","-timeout=60s","./tools/language-docs",
                 "-run","^("+"|".join(parents)+")$"],SOURCE,90)
        events=[json.loads(line) for line in raw.splitlines() if line.strip()]
        seen_run={};terminal={}
        for event in events:
            assert event.get("Package")=="github.com/electrikmilk/cherri/tools/language-docs"
            if event.get("Test"):
                test=event["Test"];assert test in expected,test
                if event["Action"]=="run":
                    assert test not in seen_run;seen_run[test]=event
                if event["Action"] in ("pass","fail","skip"):
                    assert test in seen_run and test not in terminal
                    terminal[test]=event["Action"]
        assert set(seen_run)==expected and set(terminal)==expected
        assert set(terminal.values())=={"pass"}
        assert [x["Action"] for x in events if "Test" not in x and x["Action"] in ("pass","fail","skip")]==["pass"]
        reference=target.read_bytes()
        assert reference==(SOURCE/"docs/language-v2/actions-reference.md").read_bytes()
        assert reference.count(b"\n### ")==520
        clean("05-after")
        write("generation-report.json",{"compilerCommit":SHA,"source":str(SOURCE),"startedAt":started,"finishedAt":utc(),
              "canonicalReference":{"path":str(target),"sha256":digest(target),"bytes":len(reference)},
              "namedPass":len(expected),"parents":parents,"rejectedGenerationMutations":mutations,
              "nativeSignatures":505,"separateMacroSignatures":15,"sourceCleanBeforeAndAfter":True,
              "candidateOnly":True,"docsPublished":False})
        print(json.dumps({"phase":"generation","compilerCommit":SHA,"namedPass":len(expected),"referenceSha256":digest(target)}))
except BaseException as error:
    write("failure.json",{"phase":args.phase,"startedAt":started,"finishedAt":utc(),"errorType":type(error).__name__,
                         "error":str(error),"candidateOnly":True,"docsPublished":False})
    raise
