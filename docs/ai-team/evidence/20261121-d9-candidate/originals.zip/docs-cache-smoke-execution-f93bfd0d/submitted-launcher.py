import pathlib,subprocess,json,hashlib,datetime,time,shutil,os,sys,re,ast,traceback
B=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-9c8daf72-20261121")
W=pathlib.Path(r"C:\Users\DAVID\Code\cherrilang-p10r15-docs-d9-20261121")
S=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-source-9c8daf72-exact-20261121")
C=B/"docs-smoke-cache";E=B/"docs-cache-smoke-execution-f93bfd0d";E.mkdir(exist_ok=False)
(E/"submitted-launcher.py").write_bytes(pathlib.Path(__file__).read_bytes())
source="9c8daf721aa241127df8d1e3f91bbadf90110e73";docs="f93bfd0db1fd2b99fc2b9eaacf48a2310ab236b6"
compiler=B/"build-execution-retry-2/compiler.exe"
wrong=B.parent/"r6-docs-c46902bb-20261121/compiler-exact.exe"
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
receipt={"source":source,"docs":docs,"startedAt":now(),"scope":"Actual D9 source cache controls and snippet compilation only; no docs-main/Pages or Apple execution","processes":[]}
def save(): (E/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
def run(name,cmd,cwd,budget,env=None):
 rec={"name":name,"command":[str(x) for x in cmd],"cwd":str(cwd),"budgetSeconds":budget,"startedAt":now()}
 out=E/(name+".stdout");err=E/(name+".stderr");start=time.monotonic()
 with out.open("wb") as of,err.open("wb") as ef:
  p=subprocess.Popen([str(x) for x in cmd],cwd=cwd,env=env,stdout=of,stderr=ef);rec["pid"]=p.pid
  receipt["active"]=rec;save()
  try:rec["exitCode"]=p.wait(timeout=budget);rec["timedOut"]=False
  except subprocess.TimeoutExpired:
   rec["timedOut"]=True
   k=subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=15)
   (E/(name+".owned-tree-stop.stdout")).write_bytes(k.stdout);(E/(name+".owned-tree-stop.stderr")).write_bytes(k.stderr)
   rec["exitCode"]=p.wait(timeout=15)
 rec.update(elapsedSeconds=round(time.monotonic()-start,3),finishedAt=now(),stdoutPath=out.name,stdoutSha256=sha(out),stderrPath=err.name,stderrSha256=sha(err))
 receipt["processes"].append(rec);receipt.pop("active",None);save()
 if rec["timedOut"] or rec["exitCode"]!=0:raise RuntimeError(name+" failed or timed out")
 return out.read_bytes()
def git(name,cwd,*args):return run(name,["git","--no-replace-objects",*args],cwd,60).decode().strip()
def clean(name,cwd,expected):
 assert git(name+"-head",cwd,"rev-parse","HEAD")==expected
 assert git(name+"-status",cwd,"status","--porcelain=v1","--untracked-files=all","--ignored=matching")==""
try:
 assert sha(compiler)=="cd38fbc67d27531a616d11194dab148f0dfca6f0451d055894215ec5216f6761"
 assert sha(wrong)=="6303d01498e52fc2fddda194bee0483a1cf69e492a9c3a11c16eb922302573c3"
 clean("01-docs-before",W,docs);clean("02-source-before",S,source)
 assert C.is_dir() and (C/"src/.git").is_dir()
 clean("03-existing-cache-before",C/"src",source)
 assert sha(C/"cherri.exe")==sha(compiler)
 cache_receipt=json.loads((C/"compiler-receipt.json").read_bytes())
 assert cache_receipt=={"formatVersion":1,"compilerRepository":"https://github.com/davidpovarsky/cherri.git","compilerCommit":source,"binarySha256":sha(compiler),"vcsModified":False}
 receipt["sourceFilesBefore"]={p:sha(W/p) for p in ("scripts/test_smoke_test_snippets.py","scripts/smoke_test_snippets.py")}
 receipt["existingCacheReceiptSha256"]=sha(C/"compiler-receipt.json")
 receipt["originalFailedAttempt"]="docs-cache-smoke-execution/receipt.json"
 expected=["test_valid_cache_reuses_verified_binary_without_rebuild","test_wrong_real_binary_rejected_even_with_matching_digest_receipt","test_corrupt_binary_digest_rejected_and_bytes_preserved","test_dirty_tracked_source_rejected_and_preserved","test_untracked_source_rejected_and_preserved","test_missing_receipt_does_not_rebuild_or_delete_binary","test_unmanaged_directory_is_not_deleted_or_modified","test_occupied_empty_directory_is_not_used","test_failed_fetch_cleans_only_the_owned_stage","test_actual_valid_check_and_native_plist","test_exact_invalid_diagnostic_and_no_output","test_wrong_expected_diagnostic_does_not_pass"]
 tree=ast.parse((W/"scripts/test_smoke_test_snippets.py").read_text(encoding="utf-8"))
 actual=[n.name for c in tree.body if isinstance(c,ast.ClassDef) and c.name=="SmokeProductionTests" for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith("test_")]
 assert len(actual)==12 and set(actual)==set(expected)
 receipt["fixedCacheInventory"]=expected;receipt["cacheCompilerSha256"]=sha(C/"cherri.exe");receipt["wrongBinarySha256"]=sha(wrong)
 env=os.environ.copy();env.update({"PYTHONDONTWRITEBYTECODE":"1","CHERRI_SMOKE_CACHE_DIR":str(C),"CHERRI_SMOKE_TEST_CACHE":str(C),"CHERRI_SMOKE_TEST_WRONG_BINARY":str(wrong)})
 receipt["explicitEnvironment"]={k:env[k] for k in ["PYTHONDONTWRITEBYTECODE","CHERRI_SMOKE_CACHE_DIR","CHERRI_SMOKE_TEST_CACHE","CHERRI_SMOKE_TEST_WRONG_BINARY"]};save()
 run("07-cache-controls",[sys.executable,"-B","scripts/test_smoke_test_snippets.py"],W,180,env)
 raw=(E/"07-cache-controls.stderr").read_text(encoding="utf-8")
 names=re.findall(r"^(test_[a-z_]+) \([^\r\n]+\) \.\.\. ok\s*$",raw,re.M)
 assert len(names)==12 and set(names)==set(expected),(names,raw)
 assert re.search(r"Ran 12 tests in [0-9.]+s\s+OK\s*$",raw),raw
 witness_lines=(E/"07-cache-controls.stdout").read_text(encoding="utf-8").splitlines()
 witnesses=[json.loads(line.removeprefix("CACHE_SOURCE_WITNESS ")) for line in witness_lines if line.startswith("CACHE_SOURCE_WITNESS ")]
 sequences={
  "test_corrupt_binary_digest_rejected_and_bytes_preserved":["acquire","release"],
  "test_dirty_tracked_source_rejected_and_preserved":["acquire","same-byte-replacement-rejected","remove-owned-file","restore-owned-file","release"],
  "test_missing_receipt_does_not_rebuild_or_delete_binary":["acquire","release"],
  "test_untracked_source_rejected_and_preserved":["acquire","same-byte-replacement-rejected","remove-owned-file","remove-owned-file","release"],
  "test_valid_cache_reuses_verified_binary_without_rebuild":["acquire","release"],
  "test_wrong_real_binary_rejected_even_with_matching_digest_receipt":["acquire","release"],
 }
 assert len(witnesses)==18 and {row["case"] for row in witnesses}==set(sequences)
 pristine=None;case_caches=[]
 for case,events in sequences.items():
  rows=[row for row in witnesses if row["case"]==case]
  assert [row["event"] for row in rows]==events
  assert len({row["cache"] for row in rows})==1
  case_caches.append(rows[0]["cache"])
  acquire,release=rows[0],rows[-1]
  assert acquire["binarySha256"]==sha(compiler)
  assert acquire["sourceState"]==release["sourceState"]
  state=acquire["sourceState"]
  assert state["revision"]==source and state["origin"]=="https://github.com/davidpovarsky/cherri.git"
  assert state["status"]=="" and state["autocrlf"]=="false"
  assert state["goModSha256"]==sha(S/"go.mod")
  for key in ("trackedStageSha256","trackedFlagsSha256"):
   assert re.fullmatch("[0-9a-f]{64}",state[key])
  if pristine is None:pristine=state
  assert state==pristine
 assert len(set(case_caches))==6
 receipt["cacheSourceWitnesses"]=witnesses
 receipt["fixedLeaseSequences"]=sequences
 receipt["sourceFixtureStateUnchanged"]=True
 save()
 run("08-docs-smoke",[sys.executable,"-B","scripts/smoke_test_snippets.py","--evidence-out",str(E/"snippets.original.json")],W,180,env)
 smoke=json.loads((E/"snippets.original.json").read_bytes())
 assert smoke["passed"] is True and smoke["executed"]==39 and smoke["runnable"]==36 and smoke["diagnostic"]==3
 assert smoke["compilerCommit"]==source and smoke["binarySha256"]==sha(compiler)
 assert all(r.get("passed") is True for r in smoke["records"] if r["executed"])
 clean("09-docs-after",W,docs);clean("10-cache-source-after",C/"src",source);clean("11-original-source-after",S,source)
 assert sha(compiler)==receipt["cacheCompilerSha256"]==sha(C/"cherri.exe")
 assert sha(wrong)==receipt["wrongBinarySha256"]
 assert sha(C/"compiler-receipt.json")==receipt["existingCacheReceiptSha256"]
 assert {p:sha(W/p) for p in receipt["sourceFilesBefore"]}==receipt["sourceFilesBefore"]
 receipt.update(status="PASSED",cacheControls=12,executedSnippets=39,runnable=36,diagnostic=3,referenceOnly=smoke["referenceOnly"],sourceCleanBeforeAndAfter=True,docsCleanBeforeAndAfter=True,finishedAt=now(),snippetReceiptSha256=sha(E/"snippets.original.json"))
 save();print(json.dumps({k:v for k,v in receipt.items() if k not in ["processes","fixedCacheInventory"]},indent=2))
except Exception as e:
 receipt.update(status="FAILED",error=str(e),finishedAt=now());save();traceback.print_exc();sys.exit(1)
