import pathlib,subprocess,json,datetime,time,sys,hashlib
e=pathlib.Path(r"C:\Users\DAVID\Code\cherri-p10r15-continuation-evidence-20261119\r6-docs-9c8daf72-20261121")
script=e/"source-build-and-generation.py"
assert hashlib.sha256(script.read_bytes()).hexdigest()=="ae78c04265c72659b63ff80fcdae06c54a8fa3853125ff566e0c8f9cafbab8bb"
assert not (e/"build-execution").exists() and not (e/"generation-execution").exists()
guard=e/"assigned-slot-execution"
guard.mkdir()
(guard/"submitted-launcher.py").write_bytes(pathlib.Path(__file__).read_bytes())
receipt={"compilerCandidate":"9c8daf721aa241127df8d1e3f91bbadf90110e73","startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"phases":[],"publication":False,"finalPinsChanged":False}
def save(): (guard/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
save()
for phase,budget in [("build",660),("generation",480)]:
 out=guard/(phase+".stdout");err=guard/(phase+".stderr")
 row={"phase":phase,"command":[sys.executable,"-B",str(script),"--phase",phase],"processBudget":budget,"startedAt":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 receipt["phases"].append(row);save()
 start=time.monotonic()
 with out.open("xb") as stdout,err.open("xb") as stderr:
  p=subprocess.Popen(row["command"],stdout=stdout,stderr=stderr)
  row["pid"]=p.pid;save()
  try: row["exitCode"]=p.wait(timeout=budget);row["timedOut"]=False
  except subprocess.TimeoutExpired:
   row["timedOut"]=True
   stop=subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=20)
   (guard/(phase+".owned-stop.stdout")).write_bytes(stop.stdout)
   (guard/(phase+".owned-stop.stderr")).write_bytes(stop.stderr)
   row["exitCode"]=p.wait(timeout=20)
 row.update(elapsedSeconds=round(time.monotonic()-start,6),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            stdoutSha256=hashlib.sha256(out.read_bytes()).hexdigest(),stderrSha256=hashlib.sha256(err.read_bytes()).hexdigest())
 save()
 if row["exitCode"] or row["timedOut"]:
  receipt["status"]="FAILED";receipt["finishedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
  print(json.dumps(receipt,indent=2));sys.exit(1)
receipt["status"]="PASSED_BUILD_AND_GENERATION";receipt["finishedAt"]=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(receipt,indent=2))
